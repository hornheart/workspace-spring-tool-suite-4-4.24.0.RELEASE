insert into employee(id,name,email,phone) 
values(employee_id_seq.nextval,'KIM','kim@spring.org','011-111-1111');
insert into employee(id,name,email,phone) 
values(employee_id_seq.nextval,'LEE','lee@spring.org','011-222-2222');
insert into employee(id,name,email,phone) 
values(employee_id_seq.nextval,'PARK','park@spring.org','011-333-3333');
insert into employee(id,name,email,phone) 
values(employee_id_seq.nextval,'CHOI','choi@spring.org','011-444-4444');
insert into employee(id,name,email,phone) 
values(employee_id_seq.nextval,'SIM','sim@spring.org','011-555-5555');
commit;