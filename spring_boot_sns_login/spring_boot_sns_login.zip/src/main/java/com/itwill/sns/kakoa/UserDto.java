package com.itwill.sns.kakoa;

public class UserDto {

}
