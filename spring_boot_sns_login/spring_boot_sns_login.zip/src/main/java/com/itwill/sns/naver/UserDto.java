package com.itwill.sns.naver;

public class UserDto {

}
