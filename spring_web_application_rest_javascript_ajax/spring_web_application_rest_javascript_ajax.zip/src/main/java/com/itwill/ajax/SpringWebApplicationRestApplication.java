package com.itwill.ajax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebApplicationRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebApplicationRestApplication.class, args);
	}

}
