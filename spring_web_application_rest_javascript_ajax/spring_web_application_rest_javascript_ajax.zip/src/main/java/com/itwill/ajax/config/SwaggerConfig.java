package com.itwill.ajax.config;

public class SwaggerConfig {


}