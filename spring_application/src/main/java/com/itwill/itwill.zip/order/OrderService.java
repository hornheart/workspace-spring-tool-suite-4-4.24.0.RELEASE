package com.itwill.order;

import java.util.List;

public interface OrderService {
	public List<Order> list();
}