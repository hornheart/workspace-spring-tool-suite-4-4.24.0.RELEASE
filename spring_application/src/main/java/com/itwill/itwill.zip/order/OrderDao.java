package com.itwill.order;

import java.util.List;

public interface OrderDao {
	
	public List<Order> list();
}